//
//  LazyCharacterStream.swift
//  SwiftParsec
//
//  Created by David Dufresne on 2015-10-11.
//  Copyright © 2015 David Dufresne. All rights reserved.
//
/*
public struct LazyCharacterStream: CollectionType {
    
    public typealias SubSequence = LazyCharacterStream
    
    public typealias Index = Int
    
    var startIndex: Int { return 0 }
    
    var endIndex: Int { return count }

}
*/